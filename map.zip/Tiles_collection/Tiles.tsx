<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Tiles" tilewidth="128" tileheight="128" tilecount="256" columns="16" tilerendersize="grid">
 <image source="Tiles.png" width="2048" height="2048"/>
 <tile id="0">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="allow_recover" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="allow_build" type="bool" value="false"/>
   <property name="allow_recover" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="allow_recover" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="allow_recover" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="0.9"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="allow_recover" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="0.7"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="16">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="20">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="21">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="22">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="26">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="27">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="28">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="29">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="30">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="31">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="32">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="33">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="36">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="37">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="40">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="45">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="46">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="47">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="48">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="49">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="50">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="53">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="54">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="55">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="59">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="60">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="61">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="62">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="63">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="64">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="65">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="66">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="67">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="68">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="69">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="70">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="72">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="73">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="74">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="75">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="76">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="77">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="78">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="79">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="80">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="81">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="82">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="83">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="84">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="85">
  <properties>
   <property name="allow_build" type="bool" value="false"/>
   <property name="biom" type="int" value="1"/>
   <property name="damage" type="float" value="25"/>
   <property name="friction" type="float" value="10"/>
   <property name="radiation" type="float" value="50"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="86">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="87">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="88">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="89">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="90">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="91">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="92">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="94">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="95">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="96">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="97">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="98">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="99">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="100">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="101">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="102">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="103">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="104">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="105">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="106">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="107">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="108">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="109">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="110">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="111">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="112">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="114">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="115">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="116">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="117">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="118">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="119">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="120">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="121">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="122">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="123">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="124">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="125">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="127">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="128">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="129">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="131">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="132">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="133">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="134">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="135">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="1"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="1"/>
  </properties>
 </tile>
 <tile id="136">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="137">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="138">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="139">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="2"/>
   <property name="friction" type="float" value="0"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="-1"/>
  </properties>
 </tile>
 <tile id="140">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="141">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="142">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="143">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="3"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="1"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="144">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="145">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="146">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="147">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="148">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="149">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="150">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="151">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="152">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="153">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="154">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="155">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="156">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="157">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="158">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="159">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="160">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="161">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="162">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="163">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="164">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="165">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="166">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="167">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="168">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="169">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="170">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="171">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="172">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="173">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="174">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="175">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="176">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="177">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="178">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="179">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="180">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="181">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="182">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="183">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="184">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="185">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="186">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="187">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="188">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="189">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="190">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="191">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="192">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="193">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="194">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="195">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="196">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="197">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="198">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="199">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="200">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="201">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="202">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="203">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="204">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="205">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="206">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="207">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="208">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="209">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="210">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="211">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="212">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="213">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="214">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="215">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="216">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="217">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="218">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="219">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="220">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="221">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="222">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="223">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="224">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="225">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="226">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="227">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="228">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="229">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="230">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="231">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="232">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="233">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="234">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1.2"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="235">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="236">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="237">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="238">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="239">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="biom" type="int" value="0"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="240">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="241">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="242">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="243">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="244">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="245">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="246">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="247">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="248">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="249">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="250">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="251">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="252">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="253">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="254">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <tile id="255">
  <properties>
   <property name="allow_build" type="bool" value="true"/>
   <property name="friction" type="float" value="1"/>
   <property name="radiation" type="float" value="0"/>
   <property name="speed" type="float" value="1"/>
   <property name="temperature" type="int" value="0"/>
  </properties>
 </tile>
 <wangsets>
  <wangset name="Лес (Реки и озера)" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="0" probability="1"/>
   <wangcolor name="" color="#00ff00" tile="81" probability="1"/>
   <wangtile tileid="0" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="64" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="65" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="66" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="80" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="81" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="82" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="96" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="97" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="98" wangid="0,1,0,1,0,1,0,2"/>
   <wangtile tileid="112" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="113" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="128" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="129" wangid="0,2,0,2,0,2,0,1"/>
  </wangset>
  <wangset name="Лес (Дорожки)" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="0" probability="1"/>
   <wangcolor name="" color="#00ff00" tile="33" probability="1"/>
   <wangtile tileid="0" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="16" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="17" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="18" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="32" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="33" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="34" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="48" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="49" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="50" wangid="0,1,0,1,0,1,0,2"/>
   <wangtile tileid="114" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="115" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="130" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="131" wangid="0,2,0,2,0,2,0,1"/>
  </wangset>
  <wangset name="Пустыня (Реки и озера)" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="4" probability="1"/>
   <wangcolor name="" color="#00ff00" tile="85" probability="1"/>
   <wangtile tileid="4" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="68" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="69" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="70" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="84" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="85" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="86" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="100" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="101" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="102" wangid="0,1,0,1,0,1,0,2"/>
   <wangtile tileid="116" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="117" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="132" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="133" wangid="0,2,0,2,0,2,0,1"/>
  </wangset>
  <wangset name="Пустыня (Дорожки)" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="4" probability="1"/>
   <wangcolor name="" color="#00ff00" tile="135" probability="1"/>
   <wangtile tileid="4" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="20" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="21" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="22" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="36" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="37" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="38" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="52" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="53" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="54" wangid="0,1,0,1,0,1,0,2"/>
   <wangtile tileid="118" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="119" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="134" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="135" wangid="0,2,0,2,0,2,0,1"/>
  </wangset>
  <wangset name="Север (Реки и озера)" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="8" probability="1"/>
   <wangcolor name="" color="#00ff00" tile="89" probability="1"/>
   <wangtile tileid="8" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="72" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="73" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="74" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="88" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="89" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="90" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="104" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="105" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="106" wangid="0,1,0,1,0,1,0,2"/>
   <wangtile tileid="120" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="121" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="136" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="137" wangid="0,2,0,2,0,2,0,1"/>
  </wangset>
  <wangset name="Север (Дорожки)" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="8" probability="1"/>
   <wangcolor name="" color="#00ff00" tile="41" probability="1"/>
   <wangtile tileid="8" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="24" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="25" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="26" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="40" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="41" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="42" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="56" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="57" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="58" wangid="0,1,0,1,0,1,0,2"/>
   <wangtile tileid="122" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="123" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="138" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="139" wangid="0,2,0,2,0,2,0,1"/>
  </wangset>
  <wangset name="Северная граница" type="corner" tile="-1">
   <wangcolor name="Снег" color="#ff0000" tile="8" probability="1"/>
   <wangcolor name="Трава" color="#00ff00" tile="0" probability="1"/>
   <wangtile tileid="0" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="8" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="149" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="150" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="165" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="166" wangid="0,2,0,2,0,2,0,1"/>
   <wangtile tileid="192" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="193" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="194" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="208" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="210" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="224" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="225" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="226" wangid="0,1,0,1,0,1,0,2"/>
  </wangset>
  <wangset name="Южная граница" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="4" probability="1"/>
   <wangcolor name="" color="#00ff00" tile="0" probability="1"/>
   <wangtile tileid="0" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="4" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="144" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="145" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="146" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="147" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="148" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="160" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="162" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="163" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="164" wangid="0,1,0,1,0,1,0,2"/>
   <wangtile tileid="176" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="177" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="178" wangid="0,2,0,2,0,2,0,1"/>
  </wangset>
 </wangsets>
</tileset>
