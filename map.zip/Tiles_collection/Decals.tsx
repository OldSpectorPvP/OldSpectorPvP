<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="Decals" tilewidth="128" tileheight="128" tilecount="256" columns="16" tilerendersize="grid">
 <image source="Decals.png" width="2048" height="2048"/>
</tileset>
